import { Injectable } from '@angular/core';

@Injectable()
export class EducationService {

  schools = ['education 1','education 2','education 3'];

  constructor() { }

}
