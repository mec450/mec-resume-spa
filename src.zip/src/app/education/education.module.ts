import {NgModule} from "@angular/core";
import {EducationComponent} from "./education.component";

@NgModule({
  declarations: [EducationComponent],
  imports: [],
  providers: [],
  exports: [EducationComponent]
})
export class EducationModule { }
