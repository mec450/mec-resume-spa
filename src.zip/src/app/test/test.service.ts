import { Injectable } from '@angular/core';

@Injectable()
export class TestService {

  schools = ['test 1','test 2','test 3'];

  constructor() { }

}
