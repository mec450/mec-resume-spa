export const clock = (state = new Date()) => {
  return state;
}
