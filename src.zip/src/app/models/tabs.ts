export class Tabs {
  constructor(
    public _id: string,
    public author: any,
    public overview: any
  ){}
}
