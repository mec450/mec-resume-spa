export interface Categories {
  _id: string;
  tabs: Array<{ title: string; content: string; }>;
  overview: string;
}
