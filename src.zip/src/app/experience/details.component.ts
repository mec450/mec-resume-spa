import { Component } from '@angular/core';
import { ExperienceService } from './experience.service';
@Component({
  selector: 'tech-details',
  template: '<div>???</div>',
  styleUrls: ['./experience.component.css']
})
export class DetailsComponent {
  constructor(private exp:ExperienceService){

  }
}
