import {NgModule} from "@angular/core";
import {DetailsComponent} from "./details.component";


@NgModule({
  declarations: [DetailsComponent],
  imports: [],
  providers: [],
  exports: [DetailsComponent]
})
export class DetailsModule { }
