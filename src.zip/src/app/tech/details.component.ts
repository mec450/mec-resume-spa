import { Component } from '@angular/core';
import { TechService } from './tech.service';
@Component({
  selector: 'tech-details',
  template: '<div>???</div>',
  styleUrls: ['./tech.component.css']
})
export class DetailsComponent {
  constructor(private tech:TechService){

  }
}
